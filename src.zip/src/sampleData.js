export const sampleTexts = [
    "Song 1: Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    "Song 2: Vivamus luctus urna sed urna ultricies ac tempor dui sagittis.",
    "Song 3: In condimentum facilisis porta."
  ];
  