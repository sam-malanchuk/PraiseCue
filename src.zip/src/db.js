import initSqlJs from 'sql.js';

const DB_KEY = 'displays-sqlite-db';
let dbInstance = null;

export async function initDB() {
  const SQL = await initSqlJs({
    locateFile: file => `https://sql.js.org/dist/${file}`
  });
  // Load the DB image from localStorage if available
  const savedDb = localStorage.getItem(DB_KEY);
  if (savedDb) {
    // The stored string is Base64—convert back to a Uint8Array.
    const byteString = atob(savedDb);
    const buffer = new Uint8Array(byteString.length);
    for (let i = 0; i < byteString.length; i++) {
      buffer[i] = byteString.charCodeAt(i);
    }
    dbInstance = new SQL.Database(buffer);
  } else {
    // No persisted DB exists; create a new one.
    dbInstance = new SQL.Database();
    // Create a table to hold the displays.
    dbInstance.run('CREATE TABLE IF NOT EXISTS displays (id INTEGER PRIMARY KEY, text TEXT)');
  }
  return dbInstance;
}

export function saveDB() {
  if (!dbInstance) return;
  const data = dbInstance.export();
  // Convert to Base64 string.
  const str = String.fromCharCode.apply(null, data);
  const base64 = btoa(str);
  localStorage.setItem(DB_KEY, base64);
}

export function getDB() {
  return dbInstance;
}
