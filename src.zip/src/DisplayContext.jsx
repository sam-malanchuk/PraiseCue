import React, { createContext, useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import { initDB, getDB, saveDB } from './db';

export const DisplayContext = createContext();

export function DisplayProvider({ children }) {
  const [displays, setDisplays] = useState([]);

  // Initialize SQLite DB and load existing displays.
  useEffect(() => {
    async function setupDB() {
      const db = await initDB();
      const res = db.exec('SELECT * FROM displays');
      if (res.length > 0) {
        const displayRows = res[0].values.map(([id, text]) => ({ id, text }));
        setDisplays(displayRows);
      }
    }
    setupDB();
  }, []);

  // Open Socket.io connection for real-time updates.
  useEffect(() => {
    const socket = io('http://localhost:3001'); // Change to your socket server's URL.
    socket.on('newDisplay', (newDisplay) => {
      setDisplays(prev => {
        if (!prev.find(d => d.id === newDisplay.id)) {
          // Also insert into the local SQLite DB.
          const db = getDB();
          if (db) {
            db.run('INSERT OR IGNORE INTO displays (id, text) VALUES (?, ?)', [
              newDisplay.id,
              newDisplay.text
            ]);
            saveDB();
          }
          return [...prev, newDisplay];
        }
        return prev;
      });
    });
    return () => socket.disconnect();
  }, []);

  return (
    <DisplayContext.Provider value={{ displays, setDisplays }}>
      {children}
    </DisplayContext.Provider>
  );
}
